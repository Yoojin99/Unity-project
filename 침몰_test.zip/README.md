# 2D Movement
Project files for our tutorial on 2D Movement in Unity.

The complete Unity project is under "2D Movement" and the newest version of the CharacterController2D can be found [here](https://github.com/Brackeys/2D-Character-Controller).

The asset pack used for the environment is Sunny Land which you can download [here](https://assetstore.unity.com/packages/2d/characters/sunny-land-103349).

Check out our [YouTube Channel](http://youtube.com/brackeys) for more tutorials.